<?php

namespace ZnYii\App\Enums;

class AppTypeEnum
{

    const WEB = 'web';
    const API = 'api';
    const CONSOLE = 'console';

}
